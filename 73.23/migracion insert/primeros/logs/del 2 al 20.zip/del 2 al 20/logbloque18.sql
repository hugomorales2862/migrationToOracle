
180,803 filas insertadas.


27,159 filas insertadas.


101,336 filas insertadas.


27,669 filas insertadas.


3,238 filas insertadas.


7,198 filas insertadas.


8,853 filas insertadas.


157 filas insertadas.

Confirmaci�n terminada.

157 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


8,834 filas insertadas.


28,871 filas insertadas.


2,188 filas insertadas.

Confirmaci�n terminada.

2,665 filas insertadas.


21 filas insertadas.


28 filas insertadas.


1,316 filas insertadas.


2,159 filas insertadas.


148 filas insertadas.


2,650 filas insertadas.


84 filas insertadas.


66 filas insertadas.


253 filas insertadas.


128 filas insertadas.


297 filas insertadas.

Confirmaci�n terminada.

262 filas insertadas.


1,973 filas insertadas.


219 filas insertadas.


945 filas insertadas.


2 filas insertadas.


1 fila insertadas.


2 filas insertadas.


0 filas insertadas.


750 filas insertadas.


1 fila insertadas.


2,167 filas insertadas.

Confirmaci�n terminada.

382 filas insertadas.


72 filas insertadas.


236 filas insertadas.


39 filas insertadas.


Error que empieza en la l�nea: 144 del comando -
INSERT  INTO cgmcmndd
SELECT * FROM "--"@ifmx
Error en la l�nea de comandos : 145 Columna : 15
Informe de error -
Error SQL: ORA-00942: la tabla o vista no existe
[Informix][Informix ODBC Driver][Informix]The specified table (--) is not in the database. {42S02,NativeErr = -206}
ORA-02063: 2 lines precediendo a IFMX
00942. 00000 -  "table or view does not exist"
*Cause:    
*Action:

105 filas insertadas.


44 filas insertadas.


10 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.
