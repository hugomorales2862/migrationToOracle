
160 filas insertadas.


170 filas insertadas.


3,649 filas insertadas.


3,670 filas insertadas.


80,731 filas insertadas.


86,161 filas insertadas.

Confirmaci�n terminada.

28 filas insertadas.


47 filas insertadas.


930 filas insertadas.


962 filas insertadas.


5 filas insertadas.


7 filas insertadas.


8 filas insertadas.


8 filas insertadas.


3 filas insertadas.


5 filas insertadas.

Confirmaci�n terminada.

1 fila insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


4 filas insertadas.


4 filas insertadas.


5 filas insertadas.


4 filas insertadas.


8 filas insertadas.

Confirmaci�n terminada.

9 filas insertadas.


5 filas insertadas.


10 filas insertadas.


2 filas insertadas.


2 filas insertadas.


5 filas insertadas.


9 filas insertadas.

Confirmaci�n terminada.

3 filas insertadas.


6 filas insertadas.


13 filas insertadas.


13 filas insertadas.


34 filas insertadas.


52 filas insertadas.


56 filas insertadas.


83 filas insertadas.


27 filas insertadas.


52 filas insertadas.


53 filas insertadas.


58 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.
