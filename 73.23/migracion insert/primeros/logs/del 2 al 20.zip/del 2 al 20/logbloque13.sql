
Error que empieza en la l�nea: 1 del comando -
INSERT INTO aud_opaf_notas_asc
SELECT * FROM "aud_opaf_notas_asc"@ifmx
Error en la l�nea de comandos : 1 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 4 del comando -
INSERT INTO eva_evaluacion_asc
SELECT * FROM "eva_evaluacion_asc"@ifmx
Error en la l�nea de comandos : 4 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 7 del comando -
INSERT INTO aud_eva_evaluacion_asc
SELECT * FROM "aud_eva_evaluacion_asc"@ifmx
Error en la l�nea de comandos : 7 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 10 del comando -
INSERT INTO eva_notas_asc
SELECT * FROM "eva_notas_asc"@ifmx
Error en la l�nea de comandos : 10 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:
Confirmaci�n terminada.

Error que empieza en la l�nea: 15 del comando -
INSERT INTO aud_eva_notas_asc
SELECT * FROM "aud_eva_notas_asc"@ifmx
Error en la l�nea de comandos : 15 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 18 del comando -
INSERT INTO cursos_asc
SELECT * FROM "cursos_asc"@ifmx
Error en la l�nea de comandos : 18 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 21 del comando -
INSERT INTO aud_cursos_asc
SELECT * FROM "aud_cursos_asc"@ifmx
Error en la l�nea de comandos : 21 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 24 del comando -
INSERT INTO creditos_asc
SELECT * FROM "creditos_asc"@ifmx
Error en la l�nea de comandos : 24 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 27 del comando -
INSERT INTO aud_creditos_asc
SELECT * FROM "aud_creditos_asc"@ifmx
Error en la l�nea de comandos : 27 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 30 del comando -
INSERT INTO mper_asc
SELECT * FROM "mper_asc"@ifmx
Error en la l�nea de comandos : 30 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:
Confirmaci�n terminada.

Error que empieza en la l�nea: 35 del comando -
INSERT INTO aud_mper_asc
SELECT * FROM "aud_mper_asc"@ifmx
Error en la l�nea de comandos : 35 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 38 del comando -
INSERT INTO observaciones_asc
SELECT * FROM "observaciones_asc"@ifmx
Error en la l�nea de comandos : 38 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 41 del comando -
INSERT INTO aud_observaciones_asc
SELECT * FROM "aud_observaciones_asc"@ifmx
Error en la l�nea de comandos : 41 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

506,846 filas insertadas.


4,892 filas insertadas.


Error que empieza en la l�nea: 50 del comando :
INSERT INTO coc_operaciones
SELECT * FROM "coc_operaciones"@ifmx
Informe de error -
ORA-01400: no se puede realizar una inserci�n NULL en ("ADMIN"."COC_OPERACIONES"."OPE_OBSERVACION")


3,445,760 filas insertadas.


157 filas insertadas.


493 filas insertadas.


28,273 filas insertadas.


119 filas insertadas.


162 filas insertadas.


24 filas insertadas.

Confirmaci�n terminada.

34 filas insertadas.


506,848 filas insertadas.


8 filas insertadas.


26,587 filas insertadas.


26,587 filas insertadas.


5 filas insertadas.


7 filas insertadas.


8 filas insertadas.


8 filas insertadas.

Confirmaci�n terminada.

411 filas insertadas.


505 filas insertadas.


81,860 filas insertadas.


514,702 filas insertadas.


15 filas insertadas.


46 filas insertadas.


72,376 filas insertadas.


72,393 filas insertadas.


36 filas insertadas.


976 filas insertadas.


Error que empieza en la l�nea: 135 del comando -
INSERT INTO mper_firma
SELECT * FROM "mper_firma"@ifmx
Error en la l�nea de comandos : 136 Columna : 8
Informe de error -
Error SQL: ORA-00997: uso no v�lido del tipo de dato LONG
00997. 00000 -  "illegal use of LONG datatype"
*Cause:    
*Action:
Confirmaci�n terminada.

Error que empieza en la l�nea: 140 del comando -
INSERT INTO aud_mper_firma
SELECT * FROM "aud_mper_firma"@ifmx
Error en la l�nea de comandos : 141 Columna : 8
Informe de error -
Error SQL: ORA-00997: uso no v�lido del tipo de dato LONG
00997. 00000 -  "illegal use of LONG datatype"
*Cause:    
*Action:

950 filas insertadas.


1,001 filas insertadas.


78,162 filas insertadas.


44,566 filas insertadas.


5 filas insertadas.


5 filas insertadas.

Confirmaci�n terminada.
