
0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


45 filas insertadas.


63 filas insertadas.

Confirmaci�n terminada.

7 filas insertadas.


37 filas insertadas.


Error que empieza en la l�nea: 24 del comando -
INSERT INTO amc_fuentes
SELECT * FROM "tamc_fuentes"@ifmx
Error en la l�nea de comandos : 25 Columna : 15
Informe de error -
Error SQL: ORA-00942: la tabla o vista no existe
[Informix][Informix ODBC Driver][Informix]The specified table (tamc_fuentes) is not in the database. {42S02,NativeErr = -206}
ORA-02063: 2 lines precediendo a IFMX
00942. 00000 -  "table or view does not exist"
*Cause:    
*Action:

93 filas insertadas.


4 filas insertadas.


4 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


24 filas insertadas.


61 filas insertadas.


7 filas insertadas.


8 filas insertadas.

Confirmaci�n terminada.

4 filas insertadas.


6 filas insertadas.


511 filas insertadas.


616 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


22 filas insertadas.


22 filas insertadas.


338 filas insertadas.


338 filas insertadas.


1 fila insertadas.

Confirmaci�n terminada.

1 fila insertadas.


0 filas insertadas.


0 filas insertadas.


911 filas insertadas.


282 filas insertadas.


37,120 filas insertadas.


1,305 filas insertadas.


37,114 filas insertadas.

Confirmaci�n terminada.

314 filas insertadas.


238 filas insertadas.


26,672 filas insertadas.


9,480 filas insertadas.


24,882 filas insertadas.


Error que empieza en la l�nea: 136 del comando -
INSERT INTO sanciones_asc
SELECT * FROM "sanciones_asc"@ifmx
Error en la l�nea de comandos : 136 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 139 del comando -
INSERT INTO aud_sanciones_asc
SELECT * FROM "aud_sanciones_asc"@ifmx
Error en la l�nea de comandos : 139 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 142 del comando -
INSERT INTO ficha_medica_asc
SELECT * FROM "ficha_medica_asc"@ifmx
Error en la l�nea de comandos : 142 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 145 del comando -
INSERT INTO aud_ficha_medica_asc
SELECT * FROM "aud_ficha_medica_asc"@ifmx
Error en la l�nea de comandos : 145 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 148 del comando -
INSERT INTO tiempo_comando_asc
SELECT * FROM "tiempo_comando_asc"@ifmx
Error en la l�nea de comandos : 148 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 151 del comando -
INSERT INTO aud_tiempo_comando_asc
SELECT * FROM "aud_tiempo_comando_asc"@ifmx
Error en la l�nea de comandos : 151 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 154 del comando -
INSERT INTO evaluaciones_perfil_asc
SELECT * FROM "evaluaciones_perfil_asc"@ifmx
Error en la l�nea de comandos : 154 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 157 del comando -
INSERT INTO aud_evaluaciones_perfil_asc
SELECT * FROM "aud_evaluaciones_perfil_asc"@ifmx
Error en la l�nea de comandos : 157 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 160 del comando -
INSERT INTO opaf_notas_asc
SELECT * FROM "opaf_notas_asc"@ifmx
Error en la l�nea de comandos : 160 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:
Confirmaci�n terminada.
