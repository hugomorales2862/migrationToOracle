
129 filas insertadas.


271 filas insertadas.


18 filas insertadas.


65 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

126 filas insertadas.


0 filas insertadas.


114 filas insertadas.


11,600 filas insertadas.


2,031 filas insertadas.


8,622 filas insertadas.


544 filas insertadas.


1,250 filas insertadas.


1,399 filas insertadas.


1,354 filas insertadas.

Confirmaci�n terminada.

15 filas insertadas.


33 filas insertadas.


2,455 filas insertadas.


192 filas insertadas.


31 filas insertadas.


382 filas insertadas.

Confirmaci�n terminada.

769 filas insertadas.


220 filas insertadas.


19 filas insertadas.


22 filas insertadas.


14,289 filas insertadas.


1 fila insertadas.


84 filas insertadas.


172 filas insertadas.


3 filas insertadas.


1,001 filas insertadas.


17 filas insertadas.


78,783 filas insertadas.


50 filas insertadas.


1,552 filas insertadas.


10,355 filas insertadas.


605 filas insertadas.


5,738 filas insertadas.


0 filas insertadas.


324,754 filas insertadas.


1,893 filas insertadas.


16,809 filas insertadas.


9,264 filas insertadas.


Error que empieza en la l�nea: 136 del comando :
INSERT  INTO process
SELECT * FROM "process"@ifmx
Informe de error -
ORA-01843: mes no v�lido

Confirmaci�n terminada.

116,947 filas insertadas.


86 filas insertadas.


46,497 filas insertadas.


3,957 filas insertadas.


49,035 filas insertadas.


25 filas insertadas.

Confirmaci�n terminada.
