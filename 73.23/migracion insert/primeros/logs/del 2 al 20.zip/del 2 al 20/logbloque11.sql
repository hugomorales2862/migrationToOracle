
20 filas insertadas.


28,270 filas insertadas.


10 filas insertadas.


17 filas insertadas.


4,262 filas insertadas.


10,052 filas insertadas.


857 filas insertadas.

Confirmaci�n terminada.

4,452 filas insertadas.


4,908 filas insertadas.


75 filas insertadas.


100 filas insertadas.


107 filas insertadas.


136 filas insertadas.


Error que empieza en la l�nea: 42 del comando -
INSERT INTO amc_colores
SELECT * FROM "amc_colores"@ifmx
Error en la l�nea de comandos : 42 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:

Error que empieza en la l�nea: 45 del comando -
INSERT INTO aud_amc_colores
SELECT * FROM "aud_amc_colores"@ifmx
Error en la l�nea de comandos : 45 Columna : 13
Informe de error -
Error SQL: ORA-00947: no hay suficientes valores
00947. 00000 -  "not enough values"
*Cause:    
*Action:
Confirmaci�n terminada.

68 filas insertadas.


84 filas insertadas.


415 filas insertadas.


505 filas insertadas.


350 filas insertadas.


434 filas insertadas.


420 filas insertadas.


431 filas insertadas.

Confirmaci�n terminada.

10 filas insertadas.


22 filas insertadas.


0 filas insertadas.


0 filas insertadas.


18 filas insertadas.


31 filas insertadas.


20 filas insertadas.


31 filas insertadas.


4 filas insertadas.


12 filas insertadas.


10 filas insertadas.

Confirmaci�n terminada.

30 filas insertadas.


0 filas insertadas.


0 filas insertadas.


11 filas insertadas.


36 filas insertadas.


5 filas insertadas.


15 filas insertadas.


4 filas insertadas.


20 filas insertadas.


11 filas insertadas.


12 filas insertadas.


25 filas insertadas.


91 filas insertadas.


3 filas insertadas.


3 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.
