
0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

441 filas insertadas.


1,055 filas insertadas.


47 filas insertadas.


2 filas insertadas.


2 filas insertadas.


137 filas insertadas.

Confirmaci�n terminada.

193 filas insertadas.


19 filas insertadas.


4 filas insertadas.


898 filas insertadas.


639 filas insertadas.


277 filas insertadas.

Confirmaci�n terminada.

251 filas insertadas.


19 filas insertadas.


4 filas insertadas.


1,493 filas insertadas.


746 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


Error que empieza en la l�nea: 87 del comando -
INSERT INTO codemar_operaciones
SELECT * FROM "codemar_operaciones"@ifmx
Error en la l�nea de comandos : 88 Columna : 8
Informe de error -
Error SQL: ORA-00997: uso no v�lido del tipo de dato LONG
00997. 00000 -  "illegal use of LONG datatype"
*Cause:    
*Action:

0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.

0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.


0 filas insertadas.

Confirmaci�n terminada.
